package pack1;

import java.sql.*;
import java.util.*;

public class Login
{
	static Connection con;
	static String User_Id;
	public static void logging() throws Exception
	{
		/**
		 * Calling the connection class and establishing it
		 */
		int flag = 0;
		/**
		 * USING CONNECTION STATEMENT FOR CONNECTION CLASS
		 */
		
		con = DbConnection.getConnection();
		
		Statement st;
		
		st = con.createStatement();

		Scanner scan = new Scanner(System.in);
			/**
			 * GETTING THE USERID AND VALIDATING THE USER
			 */
			System.out.println("Enter the User_ID");
			User_Id = scan.next();
			String user_check = "select username from user_detail where username='"+ User_Id + "'";

			ResultSet rs1, rs, rs2, otp_rs;
			
			rs1 = st.executeQuery(user_check);

				
		if(rs1.next())
		{
			flag=1;
			//System.out.println("UserID is correct");
			//String isActiveCheck = "select * from Account where username='"+ User_Id + "' and isactive=1 and isloggedin=0";
			String isActiveCheck = "select * from Account where username='"+ User_Id + "' and isloggedin=0";						
			rs2 = st.executeQuery(isActiveCheck);
		
			if(rs2.next())
			{	
				System.out.println("UserID is correct");
			
				String otp_status = "select pswd_status from Account where username='"+ User_Id + "'";
				otp_rs = st.executeQuery(otp_status);
				otp_rs.next();
				
				int s_otp =  otp_rs.getInt("pswd_status");
				System.out.println("Status: "+s_otp);
				
				switch (s_otp) 
				{
					case 1:
						new Regular_User(User_Id, con);
						break;
					case 2:
						new Account_Blocked_User(User_Id, con);
						break;
						
					case 3:
						new ChangePassword(User_Id, con);
						break;
		
					default:
						System.out.println("Put correct input");
						break;
				}
			}
		} 

	}
}
			
	
