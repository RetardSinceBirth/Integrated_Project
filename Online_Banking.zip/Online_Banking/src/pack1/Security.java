package pack1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Security
{
	public static String question()throws Exception
	{	
		String value=null;
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		String ans=null;
		String question1=null;
		System.out.println("SELECT YOUR SECURITY QUESTION");
		System.out.println("1-YOUR PET NAME || 2-YOUR SCHOOL NAME || 3-YOUR  FAVOURITE COLOR || 4-YOUR FAVOURITE PLACE");
		int ch=Integer.parseInt(sc.readLine());
		System.out.println(ch);
		switch(ch)
		{
		case 1:
			 question1="ENTER PET NAME";
			System.out.println(question1);
			ans=sc.readLine();
			
			break;
		case 2:
			 question1="ENTER SCHOOL NAME";
			System.out.println(question1);
			 ans=sc.readLine();
			break;
		case 3:
			question1="ENTER FAVOURITE COLOR NAME";
			System.out.println(question1);
			 ans=sc.readLine();
			break;
		case 4:
			question1="ENTER FAVOURITE PLACE NAME";
			System.out.println(question1);
			 ans=sc.readLine();
			break;
		}
		return value=ans+"/"+question1;
	}
	
}
