package pack1;

import java.util.Scanner;

public class Welcome
{
	static void test()throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("WELCOME BTO BANK");
		System.out.println("SELECT 1-NEW USERS");
		System.out.println("SELECT 2-EXISTING USERS");
		System.out.println("SELECT 3-FORGOT PASSWORD");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			NewUser.information();
			break;
			
		case 2:
			Login.logging();
			break;
			
		case 3:
			ForgetClass.Forgets();
			break;
			
		default:
			System.out.println("Enter correct input"); 
			break;
		}
	}
	public static void main(String[] args)throws Exception
	{
		test();
	}
}
