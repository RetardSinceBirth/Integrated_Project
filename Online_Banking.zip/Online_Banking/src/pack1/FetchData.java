package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;

public class FetchData
{
		static String fname;
		static String lname;
		static String address;
		static String Phone_num;
		static String Tran_Date;
		static String Tran_Type;
		static int Ammount;
		static int Ammount_Bal;
		public void Data() throws Exception{
			DbConnection con = DbConnection.getInstance();
			Connection conn = con.getConnection();
			CallableStatement cs = conn.prepareCall("{call Fetch_Data(?,?,?,?,?,?)}");
			cs.setString(1, Login.User_Id);
			cs.registerOutParameter(2, java.sql.Types.VARCHAR);
			cs.registerOutParameter(3, java.sql.Types.VARCHAR);
			cs.registerOutParameter(4, java.sql.Types.VARCHAR);
			cs.registerOutParameter(5, java.sql.Types.VARCHAR);
			cs.registerOutParameter(6, java.sql.Types.INTEGER);
			cs.execute();
			fname = cs.getString(2);
			lname = cs.getString(3);
			address = cs.getString(4);
			Phone_num = cs.getString(5);
			Ammount_Bal = cs.getInt(6);
			
			
			
		}
}
