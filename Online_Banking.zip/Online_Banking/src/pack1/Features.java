package pack1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
public class Features
{
	public Features(){
		
	}
	
	FetchData fetch = new FetchData();
	
	
	public void showPage() throws SQLException, Exception{

		DbConnection con = DbConnection.getInstance();
		Connection conn = con.getConnection();
		while(true){
			System.out.println("1. Account Summary");
			System.out.println("2. Make fund transfer");
			System.out.println("3. View Passbook");
			System.out.println("4. Change Password");
			System.out.println("5. Log Out");
			String input;
			System.out.println("Provide your input in single digit (1-5): ");
			while(true){
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				input =  br.readLine();
				if(input.length()>1){
					System.out.println("Wrong input. Please enter single digit from 1 - 5");
				}
				else if(Character.digit(input.charAt(0),10) < 0){
					System.out.println("Wrong input. Please enter digit from 1 - 5");
				}
				else if(Integer.parseInt(input)>4 || Integer.parseInt(input)<0){
					System.out.println("Wrong input. Please enter digit from 1 - 5");
					
				}
				else
					break;
			}
			int in = Integer.parseInt(input);
			switch(in){
			
			case 1:
				new AccSummary();
			case 2:
				new MakeFund();
			case 3:
				new ViewPassbook();
			case 4:
				new New_Password(Login.User_Id,con.getConnection() );
			case 5:
				new LogOut();
			
			}
		}
		
	}
}
