package pack1;

import java.security.SecureRandom;

public class ForgotPassword
{
	
	static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	static SecureRandom rnd = new SecureRandom();
	public static String randomString(){
	   StringBuilder sb = new StringBuilder( 5 );
	   for( int i = 0; i < 10; i++ ) 
	      sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
	   return sb.toString();
	}
}
