package pack1;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class New_Password 
{
	public New_Password(String User_Id, Connection con) throws SQLException 
	{
		// TODO Auto-generated constructor stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the new password: ");
		String password = s.next();
		System.out.println("Retype the password: ");
		String new_pswd = s.next();
		Statement st = con.createStatement();
		int flag=0;
		do{
		if(password.equals(new_pswd))
		{
			String update_password = "Update User_Detail set password ='"+new_pswd+"' where username='"+ User_Id + "'";
			st.executeUpdate(update_password);
			flag=1;
		}
		else
		{
			new_pswd = s.next();
		}
		}while(flag==0);
	}
}
