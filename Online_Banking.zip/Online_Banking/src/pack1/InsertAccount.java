package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;
import java.text.SimpleDateFormat;

public class InsertAccount
{

	private static  String username ;
	private static  int AccN ;
	private static  int active ;
	private static  int loggedIn ;
	private static  int BelowMinBal ;
	private static  int Acc_Bal ;
	private static  int Pass_Status ;
	private static String dateInString;
	
	public InsertAccount(String username, int AccN, int active, int loggedIn, int BelowMinBal, int Acc_Bal, int Pass_Status) throws Exception{
		
		this.username = username;
		this.AccN = AccN;
		this.active = active;
		this.loggedIn = loggedIn;
		this.BelowMinBal = BelowMinBal;
		this.Acc_Bal = Acc_Bal;
		this.Pass_Status = Pass_Status;
		
		String pattern = "dd-MM-yyyy";
		dateInString =new SimpleDateFormat(pattern).format(new Date());
		
		
		
	}
	public void insert() throws Exception{
		DbConnection con = DbConnection.getInstance();
		Connection conn = con.getConnection();
		CallableStatement cs = conn.prepareCall("{call Insert_Account(?,?,?,?,?,?,?,?)}");
		cs.setString(1,Login.User_Id);
		cs.setInt(2,AccN);
		cs.setInt(3,active);
		cs.setInt(4,loggedIn);
		cs.setInt(5,BelowMinBal);
		cs.setInt(6,Acc_Bal);
		cs.setString(7,dateInString);
		cs.setInt(8,Pass_Status);
		cs.execute();
	}
}
