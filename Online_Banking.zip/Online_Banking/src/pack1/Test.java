package pack1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Test
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter name");
		int name=Integer.parseInt(sc.readLine());
		System.out.println(name);
	}
}
