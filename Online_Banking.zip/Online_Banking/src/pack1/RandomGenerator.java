package pack1;

import java.util.Random;
public class RandomGenerator
{
	static int accNum;
	static int OTP;
	
	public  int GenAccNum()
	{
		Random Ran = new Random();
		accNum=Ran.nextInt(999)*Ran.nextInt(999)+100000;
		return accNum;
	}
	public  int GenOtp()
	{
		Random Ran = new Random();
		OTP=Ran.nextInt(9999)+1000;
		return OTP;
	}
} 
