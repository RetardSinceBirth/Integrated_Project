package pack1;

public class Message
{
	private static Message obj = null;
	private Message(){
		
	}
	public static Message getInstance(){
		if(obj == null){
			obj = new Message();
			return obj;
		}
		return obj;
			
	}
	
	public void printMsg(String msg){
		System.out.println(msg);
	}
}
