package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class InsertNewUser
{
	private static  String contact ;
	private static  String email ;
	private static  String firstname ;
	private static  String lastname ;
	private static  String username ;
	private static  String dob ;
	private static  String address ;
	private static  String question ;
	private static  String answer ;
	private static  String password ;



	InsertNewUser(String contact,String email,String firstname,String lastname,String username,String dob,String address,String question,String answer,String password){
		this.contact =contact;
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.dob = dob;
		this.address = address;
		this.question = question;
		this.answer = answer;
		this.password = password;

		
	}
	
	public static void Insert() throws Exception{
		
		DbConnection con = DbConnection.getInstance();
		Connection conn = con.getConnection();
		CallableStatement cs = conn.prepareCall("{call INSERT_User_Det(?,?,?,?,?,?,?,?,?,?)}");
		cs.setString(1,firstname);
		cs.setString(2,lastname);
		cs.setString(3,username);
		cs.setString(4,contact);
		cs.setString(5,email);
		cs.setString(6,dob);
		cs.setString(7,address);
		cs.setString(8,question);
		cs.setString(9,answer);
		cs.setString(10,password);
		if(!cs.execute()){
			System.out.println("Statement executed!!");
		}
		
	}
	
		
	
}
