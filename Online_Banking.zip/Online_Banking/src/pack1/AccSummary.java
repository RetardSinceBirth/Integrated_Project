package pack1;

public class AccSummary
{
	AccSummary(){
		System.out.println("Your Account No is: " );
		System.out.println("Your User Name is: "  );
		System.out.println("Ammount in your account is: " + FetchData.Ammount_Bal);
	}
}
