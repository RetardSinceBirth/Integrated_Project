package pack1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class ForgetClass {

	static Connection con;

	public static void Forgets() throws Exception {
		int count,flag=0;
		String answer;
		/**
		 * USING CONNECTION_CLASS FOR GETTING CONNECTION
		 */
		con = DbConnection.getConnection();
		Statement st = con.createStatement();
		Scanner scan = new Scanner(System.in);
		/**
		 * GETTING THE USERID
		 */
         do
         {
		System.out.println("Enter the User_ID");
		String User_Id = scan.next();
		/**
		 * CHECKING FOR THE VALID USERID
		 */
		String user_check1 = "select username from user_detail where username='"+ User_Id + "'";
		ResultSet rs1, rs;
		rs = st.executeQuery(user_check1);

		if (rs.next()) {
			/**
			 * GET THE SECURITY QUESTION AND CHECKING THE SECURITY ANSWER
			 */
			System.out.println("A Valid User");
			String sec_quest = "select * from user_detail where username='"+ User_Id + "'";
			rs1 = st.executeQuery(sec_quest);
			rs1.next();
			String DbAnswer = rs1.getString("security_answer");
			System.out.println("" + rs1.getString("security_question"));
			answer = scan.next();
			if (answer.equals(DbAnswer)) {
				/**
				 * GENERATES A RANDOM ALPHANUMERIC PASSWORD
				 */
				String randomNum = ForgotPassword.randomString();

				System.out.println(randomNum);
				String newPassword = "update user_detail set password='"+ randomNum + "'where username='" + User_Id + "'";
				st.executeUpdate(newPassword);
				System.out.println(newPassword);
               flag=1;
				/**
				 * MAIL
				 */
               
               SimpleMailDemo obj = new SimpleMailDemo("amitgupta1511@gmail.com","Temperory Password",randomNum);
               String temp_otp = "update Account set pswd_status=3 where username='" + User_Id + "'";
               new ChangePassword(User_Id, con);
			}

			else 
			{
				/**
				 * ALLOWS THE USER TO ENTER SECURIY ANS FOR 2 TIMES
				 */
				System.out.println("Enter the Security Answer Again");
				answer = scan.next();

				for (count = 0; count < 2; count++) {

					/**
					 * IF USER ENTERS THE CORRECT ANSWER IN FURTHER ATTEMPTS
					 */
					if (answer.equals(DbAnswer)) {
						String randomNum = ForgotPassword
								.randomString();
						String newPassword = "update user_detail set password='"
								+ randomNum
								+ "' where user_id='"
								+ User_Id
								+ "'";
						st.executeUpdate(newPassword);
						System.out.println(newPassword);
                       flag=1;
						System.out.println("password Generated");
						/**
						 * Add the mail
						 */
						break;

					}// end of ifanswer
					else 
					{
						System.out.println("Enter the Security Again(Tries left=)"+ (2 - count));
						answer = scan.next();
					}
				}// end of for loop

			}// endofelse

		}// endofif
		else {
			System.out.println("Invalid Uuser");
		}
       }while(flag==0);//THIS HELPS TO ENTER THE USERID REPEATEDLY IF USER ENTER A WRONG USER_ID
	}// endofmain
}// endofclass
