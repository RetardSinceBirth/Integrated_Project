package pack1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PasswordCheck {
	public int CheckPsw(String Psw, Connection con) throws SQLException
	{
		Statement st;
		st = con.createStatement();
		String login_check = "select password from Password_Record where username='"+ Login.User_Id + "'";
		ResultSet rs;
		rs = st.executeQuery(login_check);
		int count;
		while (rs.next()) 
		{
			if(rs.getString("password").equals(Psw))
			{
				System.out.println("workeeedd");
				return -1;
			}
			else{
				System.out.println("workeeeddfasdfasd");
				
			}
		
		}
		CallableStatement cs = con.prepareCall("{call Password_Check(?,?)}");
		cs.setString(1,Login.User_Id);
		cs.setString(2,Psw);
		return 1;
	}
}
