package pack1;
import java.sql.CallableStatement;
	import java.sql.Connection;
	import java.sql.SQLException;

	public class CheckUser
	{
		public  int check(String username) throws Exception
		{
			DbConnection con = DbConnection.getInstance();
			Connection conn = con.getConnection();
			CallableStatement cs = conn.prepareCall("{call Check_User_Name(?,?)}");
			cs.setString(1,username);
			cs.registerOutParameter(2, java.sql.Types.NUMERIC);
			cs.execute();
			int flag = cs.getInt(2);
			return flag;
		}
	}
