package pack1;

public class ViewPassbook
{
	ViewPassbook(){
		System.out.println("Write 1 for Standard Passbook and 2 for Custom Passbook");
		new WriteExcelDemo("shahbhumika.93@gmail.com");
	}
}
